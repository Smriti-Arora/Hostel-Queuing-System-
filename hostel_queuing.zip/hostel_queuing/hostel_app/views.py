from datetime import timedelta
import datetime
import io
import json
import os
import base64
from django.core.files.storage import default_storage
from django.conf import settings
from django.test import Client
import qrcode
import cv2
import numpy as np
from django.shortcuts import render, redirect, get_object_or_404
from .models import Student,Attendance
from .forms import  StudentForm,AttendanceForm
from django.http import HttpResponse, JsonResponse
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
from django.core.files import File
from django.utils.timezone import now
from django.http import Http404

@csrf_exempt  # Disable CSRF for testing; consider securing this for production
def generate_qr_code(student):
    """Helper function to generate and save QR code for a student."""
    qr_data = f"{student.uni_roll_no},{student.name}"
    qr = qrcode.make(qr_data)
    qr_code_path = os.path.join(settings.MEDIA_ROOT, f"qr_codes/{student.uni_roll_no}.png")
    qr.save(qr_code_path)
    
    # Save QR code to ImageField in the Student model
    with open(qr_code_path, "rb") as qr_file:
        student.qr_code.save(f"{student.uni_roll_no}.png", File(qr_file), save=True)

def regenerate_qr_code(request, uni_roll_no):
    # Retrieve the student instance
    student = get_object_or_404(Student, uni_roll_no=uni_roll_no)
    
    # Generate a new QR code for the student
    try:
        generate_qr_code(student.uni_roll_no)  # Update this line based on your QR code generation function
        student.save()  # Save the updated student instance if necessary
        messages.success(request, 'QR code regenerated successfully!')
    except Exception as e:
        messages.error(request, f"An error occurred while regenerating QR code: {e}")

    # Redirect back to the student list or detail page
    return redirect('student_list')
def student_list(request):
    students = Student.objects.all()  # Fetch all students
    form = None

    if request.method == "POST":
        # If 'uni_roll_no' is in request.POST, update an existing student
        if 'uni_roll_no' in request.POST:
            uni_roll_no = request.POST.get('uni_roll_no')
            student_to_update = get_object_or_404(Student, uni_roll_no=uni_roll_no)
            form = StudentForm(request.POST, instance=student_to_update)  # Populate form with existing data
        else:
            # Else, we are registering a new student
            form = StudentForm(request.POST)  # New student form
    
        if form.is_valid():
            student = form.save(commit=False)
            student.save()  # Save the student to the database
            if 'uni_roll_no' in request.POST:
                messages.success(request, 'Student updated successfully!')
            else:
                messages.success(request, 'Student registered successfully!')

            # Generate QR code after saving student data
            generate_qr_code(request, student.uni_roll_no)

            return redirect('student_list')  # Redirect to avoid re-submission of form

    else:
        # For GET request, provide an empty form for a new student
        form = StudentForm() 

    return render(request, 'student_list.html', {'form': form, 'students': students})

    context = {
        'students': students,
        'form': form,
    }
    return render(request, 'student_list.html', context)
def register_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST, request.FILES)
        if form.is_valid():
            student = form.save()  # Save the new student
            messages.success(request, 'New student registered successfully!')
            generate_qr_code(request, student.uni_roll_no)  # Generate QR code
            return redirect('student_list')
        else:
            messages.error(request, 'Error registering student. Please correct the errors below.')
    else:
        form = StudentForm()

    return render(request, 'student_form.html', {'form': form})

def student_detail(request, uni_roll_no):
    """Display detailed information about a specific student."""
    student = get_object_or_404(Student, uni_roll_no=uni_roll_no)
    return render(request, 'student_detail.html', {'student': student})

def update_student(request, uni_roll_no):
    student = get_object_or_404(Student, uni_roll_no=uni_roll_no)
    
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()  # Save the changes
            messages.success(request, 'Student updated successfully!')
            return redirect('student_list')  # Redirect to the student list view
        else:
            messages.error(request, 'Error updating student. Please correct the errors below.')
    
    form = StudentForm(instance=student)
    return render(request, 'student_form.html', {'form': form, 'student': student})

def delete_student(request, uni_roll_no):
    """Delete a student and their associated QR code if it exists."""
    student = get_object_or_404(Student, uni_roll_no=uni_roll_no)
    if request.method == 'POST':
        # Delete the QR code file if it exists
        if student.qr_code:
            default_storage.delete(student.qr_code.name)  # Delete the image file from the storage
            student.qr_code.delete()  # Clear the image field in the database

        student.delete()  # Delete the student record
        messages.success(request, "Student and QR code deleted successfully!")
        return redirect('student_list')
    
    return render(request, 'confirm_delete.html', {'student': student})

def reset_form(request):
    """Reset the form and redirect to student list."""
    messages.info(request, "Form has been reset.")
    return redirect('student_list')


def view_qr_code(request, uni_roll_no):
    student = get_object_or_404(Student, uni_roll_no=uni_roll_no)
    qr_code_path = os.path.join('media', 'qr_codes', f"{uni_roll_no}.png")  # Adjust path as necessary
    return render(request, 'view_qr_code.html', {'student': student, 'qr_code_path': qr_code_path})

import logging
logger = logging.getLogger(__name__)

@csrf_exempt
def validate_qr_code(request):
    if request.method == 'POST':
        qr_code_data = request.POST.get('qr_code', '')
        logger.warning(f"Received QR Code Data: {qr_code_data}")  # Log the incoming QR code

        try:
            # Check if any student has this QR code
            student = Student.objects.get(qr_code_data=qr_code_data)
            return JsonResponse({'valid': True})
        except Student.DoesNotExist:
            logger.warning(f"No student found for QR Code: {qr_code_data}")  # Log the failure case
            return JsonResponse({'valid': False})
    return JsonResponse({'valid': False}, status=400)
def mark_attendance(request):
    if request.method == 'POST':
        try:
            # Parse the JSON body of the request
            data = json.loads(request.body)
            qr_code_data = data.get('qr_code_data')

            if not qr_code_data:
                # Return an error if QR code data is missing
                return JsonResponse({'status': 'error', 'message': 'QR code data is missing.'}, status=400)

            # Fetch the student by `uni_roll_no` (from the QR code data)
            student = get_object_or_404(Student, uni_roll_no=qr_code_data)
            current_time = now()

            # Fetch or create today's attendance entry
            attendance, created = Attendance.objects.get_or_create(
                student=student,
                date=current_time.date()
            )

            if created or attendance.status == 'Exited':
                # Mark the student as entered
                attendance.time_in = current_time
                attendance.status = 'Entered'
                attendance.save()
                message = f"Attendance marked: {student.name} entered at {attendance.time_in}."
            elif attendance.status == 'Entered':
                # Mark the student as exited
                attendance.time_out = current_time
                attendance.status = 'Exited'
                attendance.save()
                message = f"Attendance updated: {student.name} exited at {attendance.time_out}."
            else:
                # Handle unexpected status (optional)
                return JsonResponse({'status': 'error', 'message': 'Unexpected attendance status.'}, status=500)

            return JsonResponse({'status': 'success', 'message': message, 'student_name': student.name}, status=200)

        except Exception as e:
            # Handle any exceptions that may occur
            return JsonResponse({'status': 'error', 'message': f"An error occurred: {str(e)}"}, status=500)

    # If the method is not POST, render the QR scanning page (if needed)
    return render(request, 'scan_qr.html')
@csrf_exempt
def scan_qr_code(request, student_id):
    # Retrieve the student
    student = get_object_or_404(Student, uni_roll_no=student_id)
    
    # Check if the student is currently inside
    attendance_record = Attendance.objects.filter(student=student, status="Entered").last()
    
    if attendance_record and not attendance_record.time_out:
        # Mark as exited
        attendance_record.time_out = timezone.now()
        attendance_record.status = "Exited"
        attendance_record.save()
    else:
        # Mark as entered
        Attendance.objects.create(student=student, time_in=timezone.now(), status="Entered")
    
    # Redirect to attendance overview
    return redirect('attendance_overview', student_id=student.uni_roll_no)
def attendance_overview(request):
    # Get all attendance records
    attendance_records = Attendance.objects.all().select_related('student')  # Assuming 'uni_roll_no' is related to 'Student'

    return render(request, 'attendance_overview.html', {'attendance_records': attendance_records})
    
    
from django.shortcuts import render # type: ignore
import mysql.connector as sql
em=''
pwd=''
# Create your views here.
def loginaction(request):
    global em,pwd
    if request.method=="POST":
        # m=sql.connect(host="localhost",user="root",passwd="sonu@2002",database='website')
        # cursor=m.cursor()
        d=request.POST
        for key,Value in d.items():    
            if key=="username":
                em=Value
            if key=="password":
                pwd=Value  

        # c="select * from users where email='{}' and password='{}'".format(em,pwd)
        # cursor.execute(c)
        # t=tuple(cursor.fetchall())
        print(em,pwd)
        if (em=="admin" and pwd=="1234"):
        
            return redirect('/home')
        else:
            print("fail")
            return render(request,"login.html")

    return render(request,'login.html')

from django.shortcuts import render # type: ignore
import mysql.connector as sql 
fn=''
ln=''
s=''
em=''
pwd=''
# Create your views here.
def signaction(request):
    global fn,ln,s,em,pwd
    if request.method=="POST":
        m=sql.connect(host="localhost",user="root",passwd="sonu@2002",database='website')
        cursor=m.cursor()
        d=request.POST
        for key,Value in d.items():
            if key=="first_name":
                fn=Value
            if key=="last_name":
                ln=Value
            if key=="sex":
                s=Value        
            if key=="email":
                em=Value
            if key=="password":
                pwd=Value  

        c="insert into users values('{}','{}','{}','{}','{}')".format(fn,ln,s,em,pwd)
        cursor.execute(c)
        m.commit()         
    return render(request,'register.html') 

