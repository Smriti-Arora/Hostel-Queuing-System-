from django.db import models
from django.core.validators import RegexValidator
from django.utils import timezone  
from django.utils.timezone import now# Corrected import for timezone

# Define choices for your fields
ROOM_TYPE_CHOICES = [
    ('Single', 'Single'),
    ('Double', 'Double'),
    ('Triple', 'Triple'),
]

HOSTEL_TYPE_CHOICES = [
    ('Boys', 'Boys'),
    ('Girls', 'Girls'),
]

STATE_CHOICES = [
    ('Andhra Pradesh', 'Andhra Pradesh'),
    ('Telangana', 'Telangana'),
    # Add more states as needed
]

BRANCH_CHOICES = [
    ('CSE', 'Computer Science and Engineering'),
    ('ECE', 'Electronics and Communication Engineering'),
    ('EEE', 'Electrical and Electronics Engineering'),
    ('ME', 'Mechanical Engineering'),
    ('CE', 'Civil Engineering'),
    # Add more branches as needed
]

class Admin(models.Model):  # Conventionally use `Admin` instead of lowercase `admin`
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=20)
    name = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.name} - {self.username} ({self.password})"

class Student(models.Model):
    branch = models.CharField(
        max_length=100,
        choices=BRANCH_CHOICES,
        help_text="Select your branch"
    )
    uni_roll_no = models.CharField(
        max_length=45,
        primary_key=True,
        help_text="Enter your University Roll Number"
    )
    name = models.CharField(
        max_length=45,
        help_text="Enter your name"
    )
    father_name = models.CharField(
        max_length=45,
        help_text="Enter your father's name"
    )
    father_phone_no = models.CharField(
        max_length=10,
        validators=[RegexValidator(regex=r'^\d{10}$', message="Father's phone number must be 10 digits.")],
        help_text="Enter your father's phone number (10 digits)"
    )
    phone_no = models.CharField(
        max_length=10,
        validators=[RegexValidator(regex=r'^\d{10}$', message="Phone number must be 10 digits.")],
        help_text="Enter your phone number (10 digits)"
    )
    room_no = models.CharField(
        max_length=45,
        help_text="Enter your room number"
    )
    room_type = models.CharField(
        max_length=45,
        choices=ROOM_TYPE_CHOICES,
        help_text="Select your room type"
    )
    hostel_type = models.CharField(
        max_length=45,
        choices=HOSTEL_TYPE_CHOICES,
        help_text="Select your hostel type"
    )
    state = models.CharField(
        max_length=45,
        choices=STATE_CHOICES,
        help_text="Select your state"
    )
    qr_code = models.ImageField(upload_to='qr_codes/', blank=True, null=True)
    qr_code_data = models.CharField(max_length=100, blank=True, null=True)
    
    def __str__(self):
        return f"{self.name} ({self.uni_roll_no})"

    def save_qr_code(self, qr_code_image):
        self.qr_code = qr_code_image
class Attendance(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=[('Entered', 'Entered'), ('Exited', 'Exited')])
    time_in = models.DateTimeField(null=True, blank=True)
    time_out = models.DateTimeField(null=True, blank=True)
    date = models.DateField(default=now)

    def __str__(self):
        return f"{self.student.name} - {self.date} - {self.status}"