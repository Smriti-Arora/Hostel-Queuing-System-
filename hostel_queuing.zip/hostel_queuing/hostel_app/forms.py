from django import forms
from .models import Student,Attendance

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['uni_roll_no', 'name', 'father_name', 'father_phone_no', 'phone_no', 'room_no', 'room_type', 'hostel_type', 'branch', 'state']
        
        widgets = {
            'uni_roll_no': forms.TextInput(attrs={'readonly': 'readonly'})  # Make roll number readonly when updating
        }
class AttendanceForm(forms.ModelForm):
    class Meta:
        model = Attendance
        fields = ['student', 'status']
        widgets = {
            'student': forms.Select(attrs={'class': 'form-control'}),
            'status': forms.Select(choices=[('in', 'In'), ('out', 'Out')], attrs={'class': 'form-control'})
        }
    # Custom validation can be added here if needed
